# Python app: tax personalization delta

Applies to the Atlas Python app as of the conversion-map release (55 tests). After it: 74 tests. Inclusive of the previous tax-personalization delta and this round's clean-up.

## Steps (in the app folder, the one containing `app/` and `tests/`)
```bash
patch -p1 --dry-run < python-app.patch      # data.py, agent.py, main.py, static/index.html, tests/test_agent.py
patch -p1 < python-app.patch
cp -r new/* .                               # adds app/tem.py, app/static/tem.js, app/static/tem.css, tests/test_tem.py
python3 apply_data_updates.py atlas-data-updates.json .
python3 -m pytest tests/ -q                 # expect: 74 passed
```

## What changes
| File | Change |
|---|---|
| `app/tem.py` (new) | Applies the TEM Guide and TER/QLH/DTLH term sheet rules to each sleeve, position and tax lot: account gates, coverage per position, QLH lot harvest and schedule, TER best-lot order and short-term deferral, DTLH watch list, considerations, personalization options |
| `app/data.py` | Overlay scope carve-outs now list individual bonds and TEM Style Manager holdings; overlay universes come from sleeves when an account has them; TER/QLH/DTLH use the strategy's catalog minimum instead of a household-AUM proxy (the term sheets set no service minimum) |
| `app/main.py` | `GET /api/tem/{household_id}` and `GET /api/tem-book?fa=` |
| `app/agent.py` | `tax_personalization` tool, `tem` workspace, a planner branch for lot, sleeve, TEM Style Manager and tax-aware model questions; eligibility questions about TER, QLH, DTLH or TEM Style Manager Strategies open the `tem` workspace |
| `app/static/tem.js`, `tem.css` (new) | The client-page card with charts, verdicts, rule trace, model-transition links and TET notes; trims the old overlay rows and retires the TET composition card; Tax Overlay Desk chart, tour steps, guide entry. Loaded after `app.js`; `app.js` itself is unchanged |
| `tests/test_tem.py` (new), `tests/test_agent.py` | 19 new tests, including reproductions of the TER and QLH term sheets' own worked examples |
| data | `tem_personalization` rule block; tax lots and sleeves for Castellano and Okoye; new Ashford household; account facts for brackets, held-away overlap and QLH enrollment date; TER label without "(legacy Atlas ID)" |

`atlas-python-app-fixed.zip` is the complete app with this delta already applied, and the rebuild kit is updated to match (it now builds 28 households and expects 74 tests).
