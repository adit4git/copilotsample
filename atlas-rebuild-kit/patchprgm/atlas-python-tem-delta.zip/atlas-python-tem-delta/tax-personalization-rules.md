# Tax personalization in Atlas: how the TEM rules are modeled

Sources: the Guide to Tax Efficient Management Offerings (TEM Guide, 6 pp.) and the Tax Efficient Rebalancing (TER), Quarterly Loss Harvesting (QLH) and Dynamic Tax Loss Harvesting (DTLH) term sheets (2 pp. each). Every rule below carries its document and page in `rule-store.json → tem_personalization`.

## Why the old eligibility felt thin

| Gap | What the documents actually say | Now |
|---|---|---|
| One yes/no per account | Each service applies to *eligible investments* inside the account and not to the rest (TER/QLH p.1, DTLH p.1) | A verdict for every position under TER, QLH and DTLH |
| Strategy codes only (D/Q/T) | A Custom Managed account mixes sleeves; TER and QLH cover fund and ETF sleeves; DTLH supersedes QLH on CIO ETF sleeves (TEM Guide p.4) | Sleeves with their own codes; supersession shown per position |
| Carve-outs defaulted to "none" | Never applied to fixed income securities, even inside an eligible Style Manager Strategy (TER/QLH p.1); never to TEM Style Manager Strategies (TEM Guide p.4–5) | Bonds and TEM Style Manager holdings carved out, with ids, in the rule engine too |
| $250K / $500K household-AUM "minimums" | The term sheets set no service minimum and no fee ("no separate or additional fee") | Strategy minimum from the catalog when a strategy is on file |
| No mechanics | 5% lot threshold, every 91 days, turnover limit, replacement ETF for 30 days (QLH); lowest tax cost per share at 40.8% / 23.8%, short-term deferral, loss-first withdrawals (TER); market-derived thresholds, replacement ETFs, removal sells them (DTLH) | Lot-level QLH harvest, TER best-lot order and deferral, DTLH watch list |
| No client considerations | Lower tax brackets may benefit less; overlays see only this account, so wash sales across accounts are the client's to watch; TER replaces any prior lot-relief method (TEM Guide p.6, TER p.1) | "Worth raising with the client" list |
| TEM Style Manager Strategies as one rule | 35 named strategies (as of July 29, 2025), stand-alone, not in Custom Managed; six Investment Manager Models may hold them; overlays never apply to them, even inside a model (TEM Guide p.5) | Four personalization options per client, roster matches, the six models |

## The four layers

1. **Account gates** (all overlays): taxable; U.S. resident; Managed or Custom Managed Strategy; not a Premium Access Strategy. A brokerage account not yet in the program fails the program gate and points to the conversion map.
2. **Coverage, position by position** (first matching rule wins):

| Rule | Position | TER | QLH | DTLH | Source |
|---|---|---|---|---|---|
| TEM.COV.CASH | Cash, money market | n/a | n/a | n/a | TER p.1 |
| TEM.COV.TEM_SMS | In a TEM Style Manager Strategy | Manager-run | Manager-run | Manager-run | TEM Guide p.4–5 |
| TEM.COV.PAS | Premium Access Strategy | Not applied | Not applied | Not applied | Brochure p.25 |
| TEM.COV.FIXED_INCOME | Individual bond or CD | Not applied | Not applied | — | TER/QLH p.1 |
| TEM.COV.DTLH_CIO_ONLY | Anything without catalog code D | — | — | Not applied | DTLH p.1 |
| TEM.COV.OTHER | Annuity, alternative fund, private placement | Not applied | Not applied | — | TER/QLH p.1 |
| TEM.COV.UNASSIGNED | Stock with no strategy on file | Confirm | Confirm | — | TER p.1 |
| TEM.COV.DTLH_CIO | CIO ETF strategy (code D) | — | — | Applies | DTLH p.1 |
| TEM.COV.QLH_SUPERSEDED | CIO ETF strategy (code D) | — | Superseded by DTLH | — | TEM Guide p.4 |
| TEM.COV.FI_FUND | Bond ETF or bond mutual fund | Confirm | Confirm | — | TER/QLH p.1 (assumption) |
| TEM.COV.CODED | Strategy coded T / Q | Applies | Applies | — | TER/QLH p.1, TEM Guide p.4 |
| TEM.COV.NOT_CODED | Style Manager Strategy not coded | Not applied | Not applied | — | TER/QLH p.1 |

3. **Mechanics, lot by lot**: QLH harvests lots down 5% or more in covered positions, every 91 days from enrollment, then holds a replacement ETF for 30 days. TER ranks lots by tax cost per share (gain × 40.8% if held a year or less, 23.8% if longer), defers short-term gain lots that turn long-term within 31 days, and sells the largest percentage losses first for withdrawals. DTLH shows covered positions and the losses it is watching.
4. **Considerations and options**: tax bracket, held-away overlap, new money within 30 days, DTLH removal, TER replacing a prior relief method, QLH turnover limit. Options: overlays on the current strategy; Custom Managed sleeves; a TEM Style Manager Strategy (separate account if Custom Managed); an Investment Manager Model that can hold one.

## Checked against the term sheets' own examples
- **TER Term Sheet p.2**: Atlas computes the same tax costs ($450.2, −$239.7, $97.7, $142.79), the same tax cost per share and the same sell priority (B, C, D, A vs FIFO A, B, C, D).
- **QLH Term Sheet p.2**: Atlas harvests AB, CD and IJ and leaves MN (−3.9%) alone, as the term sheet does.
Both are automated tests (`tests/test_tem.py`).

## Example clients
| Client | Shows |
|---|---|
| Castellano (Custom Managed, $3.2M) | Five sleeves: DTLH on the CIO ETF sleeve with QLH superseded; TER and QLH on the SMA, fund and ETF sleeves; nothing on municipal bonds; bond ETF to confirm. QLH harvests 3 lots ($41,750); TER defers ITOT-2 (14 days, $1,700 saved); IEFA held in a spouse's IRA |
| Okoye (Managed, ClearBridge SMA, $980K) | Lots on both sides of the 5% line; DTLH not available; 24% bracket flagged; HD-2 turns long-term in 23 days |
| Ashford (new, $4.3M) | Natixis Moderate SMA/ETF Tax Aware model holding the Parametric Large Cap Core SMA: $1.8M manager-run, overlays on the ETFs only; VWO also held in a rollover IRA elsewhere |
| Lindqvist, Montgomery, Bianchi | Blocked by one gate each: residency, not in the program, Premium Access |

## Still not modeled
- The QLH portfolio turnover limit and the DTLH market-derived thresholds (not published), so Atlas doesn't predict those trades.
- "Sizable" gains for short-term deferral (undefined); Atlas lists every gain lot in the window.
- Overweight-first ordering for withdrawals (needs security-level targets).
- How bond ETFs and bond mutual funds are treated (marked Confirm).
- Guided Investing accounts (TER plus QLH or DTLH by strategy) stay in the existing MGI eligibility card.
- Held-away overlap and tax brackets are illustrative account facts; production would source them.
- The TEM Style Manager list is dated July 29, 2025. All 35 names match a strategy in the June 2026 catalog; Atlas treats a strategy as a TEM Style Manager Strategy when it is on that list (or is a direct indexing strategy), because the catalog has no flag for it.
