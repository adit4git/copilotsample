"""Merge the tax personalization data changes into an Atlas app's data files.

    python3 apply_data_updates.py atlas-data-updates.json <app_root>

rule-store.json      adds the "tem_personalization" block; relabels TER (drops "legacy Atlas ID")
fa-and-facts.json    replaces account facts for castellano, okoye, ashford; adds "offering_minimums_note"
households.json      replaces castellano and okoye (tax lots and sleeves), appends ashford
Safe to run twice.
"""
import json, sys
from pathlib import Path

upd = json.load(open(sys.argv[1], encoding='utf-8'))
data = Path(sys.argv[2]) / 'app' / 'data'
def load(n): return json.loads((data / n).read_text(encoding='utf-8'))
def save(n, obj): (data / n).write_text(json.dumps(obj, indent=2), encoding='utf-8')

rs = load('rule-store.json'); rs.update(upd['rule-store.json'])
for k, v in upd.get('offering_labels', {}).items(): rs['offerings'][k]['label'] = v
save('rule-store.json', rs)

fa = load('fa-and-facts.json')
fa['account_facts'].update(upd['fa-and-facts.json']['account_facts'])
fa['offering_minimums_note'] = upd['fa-and-facts.json']['offering_minimums_note']
save('fa-and-facts.json', fa)

hh = load('households.json')
rep = {h['id']: h for h in upd['households.json']['replace']}
hh = [rep.get(h['id'], h) for h in hh]
ids = {h['id'] for h in hh}
hh += [h for h in upd['households.json']['append'] if h['id'] not in ids]
save('households.json', hh)
print(f"rule-store: tem_personalization ({len(rs['tem_personalization']['coverage_rules'])} coverage rules) | households: {len(hh)} | account facts updated: {', '.join(upd['fa-and-facts.json']['account_facts'])}")
